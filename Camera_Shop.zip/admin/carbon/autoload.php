<?php

/**
 * @version 2.66.0
 */

require __DIR__.'/vendor/autoload.php';
